package back.scr.test.java.com.flashpage.app;

public class FlashPageApplicationTest {
    
}
