package com.flashpage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlashPageApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlashPageApplication.class, args);
	}

}
